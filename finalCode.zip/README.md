Final project for CS 320 Fundamentals of Software Engineering. 
Creators: Katie Cederdahl and Rebekah Rolfe

This project was a website created by using JavaScript, HTML, CSS, Semantic UI, and Python. The website contains craft ideas with instructions and a product list. The website is called CraftingWizards with the logo being a wizard hat made in Python and updated based on whether it's a holiday or not.

This program is complete for how far we wanted to go, with some added stuff if we really went further and wanted to expand on this project.
