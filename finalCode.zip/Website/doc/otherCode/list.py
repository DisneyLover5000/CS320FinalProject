# list function
#thoughts for list function random just thinking through the problem probably wont work 

def main(ip):
    #ask comuter for ipadress
    #take ipadress and put in to ipaddlist
    s
    
    
    
    
def ipaddlist(ip):
    if ip != listip:
        list[] = new list[]
        
    else :
        list[]= list.loadlastsave
        
    return list[]




def add():
    # if add was pushed
        #add item to list[]
        #save list to ip
    #else:
        #don nuthinf
        
        
def print():
    #loade list[] 
    #print list to html pg.
    